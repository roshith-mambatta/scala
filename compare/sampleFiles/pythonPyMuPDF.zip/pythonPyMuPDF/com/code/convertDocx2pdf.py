from docx2pdf import convert
convert("C://Users//Roshith\Desktop//In progress//BIRTsamples//file-sample_1MB.docx", "C://Users//Roshith\Desktop//In progress//BIRTsamples//file-sample_1MB.pdf")